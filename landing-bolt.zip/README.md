# Mindful Landing (Bolt-ready)
Upload this zip to bolt.new as a new project.
- Set env: VITE_APP_URL=https://app.yourdomain.com
- Run: npm run dev / npm run build